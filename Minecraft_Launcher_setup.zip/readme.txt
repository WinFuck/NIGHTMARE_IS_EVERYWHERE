put those files into C:\file folder.
and in C:\file folder start installer.cmd.